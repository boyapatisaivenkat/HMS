import React from 'react'
import Dimp from './Test/Dimp'


const Tester = () => {
    return (
        <div>
          
          <Dimp></Dimp>
        </div>
      )
}

export default Tester