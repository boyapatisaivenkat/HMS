import React from 'react'

const Welcome = () => {
  return (
    <div>
    <center>
        <hr></hr>
        <h1 style={{color: "Blue",fontSize: "50px"}}>Welcome , Srimant Mahadev</h1>
        <hr></hr>
    </center>
    </div>
  )
}

export default Welcome